

//#include "stdAfx.h"
#include "haspUtil.h"


BOOL hasp_key_login(char *msg){

	const hasp_feature_t feature = HASP_DEFAULT_FID;  

	m_hasp_handle = HASP_INVALID_HANDLE_VALUE;

	m_hasp_status = hasp_login(feature, vendor_code, &m_hasp_handle);

	/* check if operation was successful */
	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_FEATURE_NOT_FOUND:
			stringCopy(msg,"HASP_FEATURE_NOT_FOUND",32);

			break;
		case HASP_HASP_NOT_FOUND:
			stringCopy(msg,"HASP_KEY_NOT_FOUND",32);
			break;
		case HASP_OLD_DRIVER:
			stringCopy(msg,"HASP_OLD_DRIVER",32);
			break;
		case HASP_NO_DRIVER:
			stringCopy(msg,"HASP_NO_DRIVER",32);
			break;
		case HASP_INV_VCODE:
			stringCopy(msg,"HASP_INV_VCODE",32);
			break;
		case HASP_FEATURE_TYPE_NOT_IMPL:
			stringCopy(msg,"HASP_FEATURE_TYPE_NOT_IMPL",32);
			break;
		case HASP_TMOF:
			stringCopy(msg,"HASP_TMOF",32);
			break;
		case HASP_TS_DETECTED:
			stringCopy(msg,"HASP_TS_DETECTED",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}

		return false;

	}else{
		//msg="SUCCESS";
		stringCopy(msg,"SUCCESS",32);
		return true;
	}
}

BOOL hasp_key_logout(char *msg){

	m_hasp_status = hasp_logout(m_hasp_handle);

	/* check if operation was successful */
	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_INV_HND:
			stringCopy(msg,"HASP_INV_HND",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}
		return false;
	}else{
		stringCopy(msg,"SUCCESS",32);
		return true;
	}
}

BOOL hasp_key_real_time(char *msg,struct HaspKeyTime *haspTime){

	m_hasp_status = hasp_get_rtc(m_hasp_handle, &m_hasp_time);

	/* check if operation was successful */
	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_INV_HND:
			stringCopy(msg,"HASP_INV_HND",32);
			break;
		case HASP_NO_TIME:
			stringCopy(msg,"HASP_NO_TIME",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}
		return false;
	}else{

		m_hasp_status = hasp_hasptime_to_datetime(m_hasp_time, 
			&haspTime->day, 
			&haspTime->month, 
			&haspTime->year, 
			&haspTime->hour,
			&haspTime->minute, 
			&haspTime->second);

		if(m_hasp_status == HASP_INV_TIME)
		{
			/* handle error */
			stringCopy(msg,"HASP_INV_TIME",32);
			return false;
		}else{
			stringCopy(msg,"SUCCESS",32);
			/*
			TIME_ZONE_INFORMATION timeZoneInfo;
			GetTimeZoneInformation( &timeZoneInfo );

			haspTime->hour-=(int)(timeZoneInfo.Bias/60);
			*/
			return true;
		}

	}

}


BOOL hasp_key_write_data(char *msg,char *uuid,char * lib_apc_key,struct HaspKeyTime expireDate,BOOL checkFlag){

	hasp_size_t offset = 0;
	hasp_size_t len = sizeof( struct HaspKeyData);

	struct HaspKeyData *haspKeyData;
	//haspKeyData = new HaspKeyData();
	haspKeyData = (struct HaspKeyData*)malloc(sizeof(struct HaspKeyData));
    stringCopy(haspKeyData->magic,"@Brogent00",10);
	
    stringCopy(haspKeyData->UUID,uuid,80);
	stringCopy(haspKeyData->LIB_APC_KEY,lib_apc_key,32);
	haspKeyData->expireDate=expireDate;
	haspKeyData->checkFlag=checkFlag;

	//  Just date data , no motion 
	if(!hasp_key_encrypt_data(msg,haspKeyData,len)){
		return false;
	}

	m_hasp_status = hasp_write(m_hasp_handle, HASP_FILEID_RW, offset, len, haspKeyData);

	/* check if operation was successful */
	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_FEATURE_NOT_FOUND:
			stringCopy(msg,"HASP_FEATURE_NOT_FOUND",32);
			break;
		case HASP_INV_HND:
			stringCopy(msg,"HASP_INV_HND",32);
			break;
		case HASP_INV_FILEID:
			stringCopy(msg,"HASP_INV_FILEID",32);
			break;
		case HASP_MEM_RANGE:
			stringCopy(msg,"HASP_MEM_RANGE",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}
		return false;
	}else{
		stringCopy(msg,"SUCCESS",32);
		return true;
	}

}


BOOL hasp_key_write_check_flag(char *msg,BOOL checkFlag){

	
	hasp_size_t offset = 0;
	hasp_size_t len = sizeof( struct HaspKeyData);

	struct HaspKeyData *haspKeyData;
	//haspKeyData = new HaspKeyData();

	if(m_hasp_handle==NULL){
		if(!hasp_key_login(msg)){
			return false;
		}
	}

	haspKeyData = (struct HaspKeyData*)malloc(sizeof(struct HaspKeyData));
	m_hasp_status = hasp_read(m_hasp_handle, HASP_FILEID_RW, offset, len, haspKeyData);

	/* check if operation was successful */
	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_FEATURE_NOT_FOUND:
			stringCopy(msg,"HASP_FEATURE_NOT_FOUND",32);
			break;
		case HASP_INV_HND:
			stringCopy(msg,"HASP_INV_HND",32);
			break;
		case HASP_INV_FILEID:
			stringCopy(msg,"HASP_INV_FILEID",32);
			break;
		case HASP_MEM_RANGE:
			stringCopy(msg,"HASP_MEM_RANGE",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}
		return false;
	}else{

		if(!hasp_key_decrypt_data(msg,haspKeyData, len)){
			return false;
		}

		haspKeyData->checkFlag=checkFlag;

		if(!hasp_key_encrypt_data(msg,haspKeyData,len)){
			return false;
		}

		m_hasp_status = hasp_write(m_hasp_handle, HASP_FILEID_RW, offset, len, haspKeyData);

		/* check if operation was successful */
		if (m_hasp_status != HASP_STATUS_OK)
		{
			switch (m_hasp_status)
			{
			case HASP_FEATURE_NOT_FOUND:
				stringCopy(msg,"HASP_FEATURE_NOT_FOUND",32);
				break;
			case HASP_INV_HND:
				stringCopy(msg,"HASP_INV_HND",32);
				break;
			case HASP_INV_FILEID:
				stringCopy(msg,"HASP_INV_FILEID",32);
				break;
			case HASP_MEM_RANGE:
				stringCopy(msg,"HASP_MEM_RANGE",32);
				break;
			default:
				stringCopy(msg,"HASP_STATUS_NOT_READY",32);
				break;
			}
			return false;
		}else{
			stringCopy(msg,"SUCCESS",32);
			return true;
		}

	}
}


BOOL hasp_key_read_check_flag(char *msg,BOOL *checkFlag){

	

	hasp_size_t offset = 0;
	hasp_size_t len = sizeof( struct HaspKeyData);

	struct HaspKeyData *haspKeyData;
	//haspKeyData = new HaspKeyData();
	if(m_hasp_handle==NULL){
		if(!hasp_key_login(msg)){
			return false;
		}
	}
	haspKeyData = (struct HaspKeyData*)malloc(sizeof(struct HaspKeyData));
	m_hasp_status = hasp_read(m_hasp_handle, HASP_FILEID_RW, offset, len, haspKeyData);

	/* check if operation was successful */
	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_FEATURE_NOT_FOUND:
			stringCopy(msg,"HASP_FEATURE_NOT_FOUND",32);
			break;
		case HASP_INV_HND:
			stringCopy(msg,"HASP_INV_HND",32);
			break;
		case HASP_INV_FILEID:
			stringCopy(msg,"HASP_INV_FILEID",32);
			break;
		case HASP_MEM_RANGE:
			stringCopy(msg,"HASP_MEM_RANGE",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}
		return false;
	}else{

		if(!hasp_key_decrypt_data(msg,haspKeyData, len)){
			return false;
		}

		*checkFlag=haspKeyData->checkFlag;

		stringCopy(msg,"SUCCESS",32);
		return true;

	}
}

BOOL hasp_key_read_data(char *msg,char *uuid,char * lib_apc_key,SYSTEMTIME *expireDate,BOOL *checkFlag){

	hasp_size_t offset = 0;
	hasp_size_t len = sizeof( struct HaspKeyData);

	char magic[11];

	struct HaspKeyData *haspKeyData;
	//haspKeyData = new HaspKeyData();
	haspKeyData = (struct HaspKeyData*)malloc(sizeof(struct HaspKeyData));


	//haspKeyData->magic[10-1]='\0';                   //  @Brogent00 
    //haspKeyData->UUID[80-1]='\0';
	//haspKeyData->checkFlag=0;
	//haspKeyData->LIB_APC_KEY[32-1]='\0';
	//haspKeyData->reserve[902-1]='\0';
	
	m_hasp_status = hasp_read(m_hasp_handle, HASP_FILEID_RW, offset, len, haspKeyData);

	/* check if operation was successful */
	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_FEATURE_NOT_FOUND:
			stringCopy(msg,"HASP_FEATURE_NOT_FOUND",32);
			break;
		case HASP_INV_HND:
			stringCopy(msg,"HASP_INV_HND",32);
			break;
		case HASP_INV_FILEID:
			stringCopy(msg,"HASP_INV_FILEID",32);
			break;
		case HASP_MEM_RANGE:
			stringCopy(msg,"HASP_MEM_RANGE",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}
		return false;
	}else{

		if(!hasp_key_decrypt_data(msg,haspKeyData, len)){
			return false;
		}
		
		stringCopy(magic, haspKeyData->magic,10);

		if(strcmp(magic,"@Brogent00")!=0){
			stringCopy(msg,"HASP_MAGIC_ERROR",32);
			return false;
		}

		stringCopy(uuid, haspKeyData->UUID,80);
		stringCopy(lib_apc_key,haspKeyData->LIB_APC_KEY,32);
		*expireDate=transToSystemTime(haspKeyData->expireDate);
		*checkFlag=haspKeyData->checkFlag;
	
		stringCopy(msg,"SUCCESS",32);
		return true;
	}

}


BOOL hasp_key_encrypt_data(char *msg,void *buffer,hasp_size_t len){

	m_hasp_status = hasp_encrypt(m_hasp_handle,buffer, len);

	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_FEATURE_NOT_FOUND:
			stringCopy(msg,"HASP_FEATURE_NOT_FOUND",32);
			break;
		case HASP_INV_HND:
			stringCopy(msg,"HASP_INV_HND",32);
			break;
		case HASP_TOO_SHORT:
			stringCopy(msg,"HASP_TOO_SHORT",32);
			break;
		case HASP_ENC_NOT_SUPP:
			stringCopy(msg,"HASP_ENC_NOT_SUPP",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}
		return false;
	}else{
		stringCopy(msg,"SUCCESS",32);
		return true;
	}
}

BOOL hasp_key_decrypt_data(char *msg,void *buffer,hasp_size_t len){

	m_hasp_status = hasp_decrypt(m_hasp_handle, buffer, len);

	/* check if operation was successful */
	if (m_hasp_status != HASP_STATUS_OK)
	{
		switch (m_hasp_status)
		{
		case HASP_FEATURE_NOT_FOUND:
			stringCopy(msg,"HASP_FEATURE_NOT_FOUND",32);
			break;
		case HASP_INV_HND:
			stringCopy(msg,"HASP_INV_HND",32);
			break;
		case HASP_TOO_SHORT:
			stringCopy(msg,"HASP_TOO_SHORT",32);
			break; 
		case HASP_ENC_NOT_SUPP:
			stringCopy(msg,"HASP_ENC_NOT_SUPP",32);
			break;
		default:
			stringCopy(msg,"HASP_STATUS_NOT_READY",32);
			break;
		}
		return false;
	}else{
		stringCopy(msg,"SUCCESS",32);
		return true;
	}

}


BOOL hasp_key_check(char *msg){

	char uuid[80];
	char lib_apc_key[32];
	SYSTEMTIME expireDate;
	BOOL checkFlag=false;
	struct HaspKeyTime haspTime;

	if(m_hasp_handle==NULL){
		if(!hasp_key_login(msg)){
			return false;
		}
	}

	
	if(!hasp_key_real_time(msg,&haspTime)){
		return false;
	}
	
	

	if(!hasp_key_read_data(msg,uuid,lib_apc_key,&expireDate, &checkFlag)){
		return false;
	}
	
	stringCopy(msg,"SUCCESS",32);
	return true;

}

BOOL get_hasp_key_real_time(char *msg,SYSTEMTIME *systemTime){

	struct HaspKeyTime haspTime;
	if(!hasp_key_real_time(msg,&haspTime)){
		return false;
	}

	*systemTime=transToSystemTime(haspTime);

	return  true;

}

SYSTEMTIME transToSystemTime(struct HaspKeyTime time){

	SYSTEMTIME systemTime ;
	double dVariantTime;

	systemTime.wYear=time.year;
	systemTime.wMonth=time.month;
	systemTime.wDay=time.day;
	systemTime.wHour=time.hour;
	systemTime.wMinute=time.minute;
	systemTime.wSecond=time.second;
	systemTime.wMilliseconds=0;

	
	
	SystemTimeToVariantTimeWithMilliseconds (systemTime, &dVariantTime);

	VariantTimeToSystemTimeWithMilliseconds (dVariantTime, &systemTime);


	return systemTime;
}

void  stringCopy(char *strTarget, char *strSource,int lenTarget){

	int lenSource=strlen(strSource);
	int len=0;

	if( lenSource>lenTarget){
		len=lenTarget;
	}else{
		len=lenSource;
	}
	memcpy(strTarget,strSource,len);
	strTarget[len]='\0';
}

BOOL SystemTimeToVariantTimeWithMilliseconds (/*input*/ SYSTEMTIME st, /*output*/double *dVariantTime)
{
	BOOL retVal = TRUE;
	double dWithoutms;
	double OneMilliSecond =  ONETHOUSANDMILLISECONDS/1000 ;

	WORD wMilliSeconds = st.wMilliseconds;  // save the milli second information
	st.wMilliseconds = 0;  // pass 0 milliseconds to the function and get the converted value without milliseconds
	
	retVal = SystemTimeToVariantTime(&st, &dWithoutms) ;

	// manually convert the millisecond information into variant fraction and add it to system converted value
	
	*dVariantTime = dWithoutms +  (OneMilliSecond * wMilliSeconds);

	return retVal;
}

BOOL VariantTimeToSystemTimeWithMilliseconds (/*input*/ double dVariantTime, /*output*/SYSTEMTIME *st)
{
	BOOL retVal = TRUE;

	double halfsecond = ONETHOUSANDMILLISECONDS / 2.0;  // see definition of ONETHOUSANDMILLISECONDS in the header file
	double hours; 
	double minutes;
	double seconds;
	double milliseconds;
	double fraction = dVariantTime  - (int) dVariantTime;  // extracts the fraction part
	retVal = VariantTimeToSystemTime(dVariantTime - halfsecond, st);   // this takes care of rounding problem with VariantTimetoSystemTime function
	if (retVal == FALSE)
	{
		return retVal;
	}


	
	
	
	hours = fraction = (fraction - (int)fraction) * 24;

	
	minutes = (hours - (int)hours) * 60;

	
	seconds = (minutes - (int)minutes) * 60;

	
	milliseconds = (seconds - (int)seconds) * 1000;
	
	milliseconds = milliseconds + 0.5;	// rounding off millisecond to the nearest millisecond				
	if (milliseconds < 1.0 || milliseconds > 999.0)    //Fractional calculations may yield in results like
		milliseconds = 0;		   // 0.00001 or 999.9999 which should actually be zero (slightly above or below limits are actually zero)

	if (milliseconds)	
		st->wMilliseconds = (WORD) milliseconds;
	else // if there is 0 milliseconds, then we dont have the problem !!
		retVal = VariantTimeToSystemTime(dVariantTime, st);   

	return retVal;
}